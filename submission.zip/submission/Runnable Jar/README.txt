Make sure that the input files (below) are stored in the same folder as this .jar to run.
stops.txt
transfers.txt
stop_times.txt

On first time startup, it will take ~15 minutes in order to setup the floyd warshall table.
It will take only ~15 seconds on subsequent startups